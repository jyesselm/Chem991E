#!/bin/bash                                                             
#SBATCH -t 2:00:00
#SBATCH -o out.txt
cd $WORK/rosetta/runs/87
AbinitioRelax.default.linuxgccrelease -in:file:native ../../1l2y.pdb -in:file:frag3 ../../aa1l2yA03_05.200_v1_3 -in:file:frag9 ../../aa1l2yA09_05.200_v1_3 -out:nstruct 100 -out:file:silent 1l2y_silent.out